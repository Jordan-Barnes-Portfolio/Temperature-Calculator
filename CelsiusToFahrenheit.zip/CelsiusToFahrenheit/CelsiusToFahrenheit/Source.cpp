#include <fstream>
#include <iostream>
#include <string>
#include <math.h>
using namespace std;


/*here we define a function to convert the values*/
float conversionToCelsius(float fahrenheit)
{
	//defining our celsius value variable as a float
	float celsiusValue;
	//out conversion equation
	celsiusValue = (fahrenheit - 32) * (5.0 / 9.0);
	//here we are rounding our float to the nearest integer value for readability
	celsiusValue = roundf(celsiusValue);
	
	//function returns the converted value
	return celsiusValue;
}

//here we define our function to read, convert, then write our data to a new file.
void readAndConvert()
{
	//defining our variables for this function
	string line;
	string city;
	float fahrenheit;

	//opening an input and output stream to open and read/write to our respective files.
	ifstream myfile("FahrenheitTemperature.txt");
	ofstream myfileConversion("CelsiusTemperature.txt");

	//this loop iterates through each line checking for our int and string values.
	while (myfile >> city >> fahrenheit)
	{
		//since we know the file contains a string followed by an integer we can call each respectively and feed the integer value (fahrenheit) into our conversion function
		myfileConversion << city << " " << conversionToCelsius(fahrenheit) << endl;
	}

	//here we must close the files so they can be accessed by other programs.
	myfile.close();
	myfileConversion.close();
}

int main()
{
	//simplified main function calling the only function needed which is read and convert.
	readAndConvert();

}